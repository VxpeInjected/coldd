Thanks for your purchase from coldd Development!

This is a placeholder file. Once real product files are uploaded to
Supabase Storage (replacing this one), your downloads will contain the
actual asset files for what you purchased.
